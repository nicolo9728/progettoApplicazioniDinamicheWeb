export type Credenziali = Readonly<{
    username: string,
    password: string
}>