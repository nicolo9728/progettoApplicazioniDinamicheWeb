export type Token = Readonly<{
    token: string
}>