export type Result<T, E> = 
        Readonly<{success: true, value: T}> |
        Readonly<{success: false, error: E}>



export class ResultMapper<T, E>{
    private constructor(private result: Result<T, E>){}

    static from<T, E>(result: Result<T, E>) {return new ResultMapper(result)}

    public match<R>(onSuccess: (val: T) => R, onFailure: (err: E) => R){
        return this.result.success ? onSuccess(this.result.value) : onFailure(this.result.error)
    }

    public bind<R>(fun: (val: T) => Result<R, E>){
        return this.result.success 
                ? new ResultMapper(fun(this.result.value)) 
                : new ResultMapper(this.result)
    }

    public map<R>(m: (val: T)=> R){
        return this.result.success 
                ? new ResultMapper({success: true, value: m(this.result.value)})
                : new ResultMapper(this.result) 
    }
}