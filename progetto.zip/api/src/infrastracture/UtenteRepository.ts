import { injectable } from "tsyringe";
import { SqlConnectionUser } from "./SqlConnectionUser";
import { Utente } from "../models/Utente";

@injectable()
export class UtenteRepository{
    constructor(
        private sql: SqlConnectionUser
    ){}


    public async getUserByUsername(username: string): Promise<Utente | undefined>{
        const ris = await this.sql.query("SELECT * FROM utente WHERE username=$1", [username])
        return ris.length > 0 
            ? new Utente(ris[0]["id"], ris[0]["username"], ris[0]["password"])
            : undefined
    }
}