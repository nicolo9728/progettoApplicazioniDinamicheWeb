import { injectable } from "tsyringe";
import { UtenteRepository } from "../infrastracture/UtenteRepository";
import { sign } from "jsonwebtoken";
import { Utente } from "../models/Utente";
import { generateJwt } from "../auth/JwtManager";

export type CredenzialiLogin = {username: string, password: string}


@injectable()
export class LoginController{
    constructor(
        private utenteRepository: UtenteRepository
    ){}


    public async login(credenziali: CredenzialiLogin){
        const utente = await this.utenteRepository.getUserByUsername(credenziali.username)
        if(!utente)
            throw new Error("Username non trovato")

        if(utente.checkPassword(credenziali.password))
            return this.generateToken(utente)
        else
            throw new Error("Password non valida")
    }

    private generateToken(utente: Utente){
        return {
            token: generateJwt({username: utente.username, id: utente.idCustomer})
        }
    }
}