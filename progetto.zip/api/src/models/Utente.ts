import { compareSync } from "bcrypt";


export class Utente{
    constructor(
        public idCustomer: Readonly<number>,
        public username: Readonly<string>, 
        private password: Readonly<string>,
    ){}


    public checkPassword(password: string){
        return compareSync(password, this.password)
    }
}